function showTab(tabName) {
    document.querySelectorAll(".tab-content").forEach(tab => tab.style.display = "none");
    document.getElementById(tabName).style.display = "block";
}

function convertCgpaToSgpa() {
    let cgpa = parseFloat(document.getElementById("cgpaInput").value);
    if (!isNaN(cgpa)) {
        let sgpa = (cgpa + 0.75).toFixed(2);  // Example logic
        document.getElementById("sgpaResult").innerHTML = "Approx SGPA: " + sgpa;
    }
}

let semesterCount = 0;
function addSgpaInput() {
    semesterCount++;
    let div = document.createElement("div");
    div.innerHTML = `Semester ${semesterCount}: <input type="number" class="sgpa" step="0.01" max="10"><br>`;
    document.getElementById("sgpaInputs").appendChild(div);
}

function convertSgpaToCgpa() {
    let inputs = document.querySelectorAll(".sgpa");
    let total = 0;
    let count = 0;
    inputs.forEach(input => {
        let val = parseFloat(input.value);
        if (!isNaN(val)) {
            total += val;
            count++;
        }
    });
    let cgpa = (total / count).toFixed(2);
    document.getElementById("cgpaResult").innerHTML = "Calculated CGPA: " + cgpa;
}

function convertToPercentile() {
    let grade = parseFloat(document.getElementById("gradeInput").value);
    if (!isNaN(grade)) {
        let percent = (grade * 9.5).toFixed(2); // Standard 9.5 formula
        document.getElementById("percentileResult").innerHTML = "Approx Percentile: " + percent + "%";
    }
}

function toggleTheme() {
    document.body.classList.toggle("dark");
}
